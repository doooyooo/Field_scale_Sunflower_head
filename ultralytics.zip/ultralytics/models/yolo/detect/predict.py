# Ultralytics YOLO 🚀, AGPL-3.0 license

from ultralytics.engine.predictor import BasePredictor
from ultralytics.engine.results import Results
from ultralytics.utils import ops


class DetectionPredictor(BasePredictor):
    """
    A class extending the BasePredictor class for prediction based on a detection model.

    Example:
        ```python
        from ultralytics.utils import ASSETS
        from ultralytics.models.yolo.detect import DetectionPredictor

        args = dict(model='yolov8n.pt', source=ASSETS)
        predictor = DetectionPredictor(overrides=args)
        predictor.predict_cli()
        ```
    """

    def postprocess(self, preds, img, orig_imgs):
        """Post-processes predictions and returns a list of Results objects."""
        preds = ops.non_max_suppression(
            preds,
            self.args.conf,
            self.args.iou,
            agnostic=self.args.agnostic_nms,
            max_det=self.args.max_det,
            classes=self.args.classes,
        )

        if not isinstance(orig_imgs, list):  # input images are a torch.Tensor, not a list
            orig_imgs = ops.convert_torch2numpy_batch(orig_imgs)
        f = lambda x: 4 if 4 <= x <= 16 else 4
        bs = f(orig_imgs[0].shape[-1])
        results = []
        p = []
        for pred, orig_img, img_path in zip(preds, orig_imgs, self.batch[0]):
            pred[:, :4] = ops.scale_boxes(img.shape[2:], pred[:, :4], orig_img[...,-3:].shape)
            results.append(Results(orig_img[...,-3:], path=img_path, names=self.model.names, boxes=pred))
            batch = img_path.split('ges')
            batch = str(batch[0] + 'ge' + batch[1])
            if orig_img.shape[-1] >= bs:
                p.append(Results(orig_img[...,:3], path=batch, names=self.model.names, boxes=pred))
        return results, p if orig_img.shape[-1] >= bs else results


